/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author jose_
 */
public class Cotizante extends Paciente  {

    private double salario;
    private double celular;
    private Beneficiario suBeneficiario;

    public Cotizante(double salario, double celular, String nombre, int numId, int numRegistro) {
        super(nombre, numId, numRegistro);
        this.salario = salario;
        this.celular = celular;
    }
  public double traerCopago(){
       double res=0.0;
       
       res = suBeneficiario.determinarCuotaCopago();
       
       return res;
    }
    
        public int  calcularRangoSalarial() {
        int  res;
        if (salario <= 1817051) {
             res = 1;
        } else {
            if ( salario <= 4542631) {
                res = 2;
            } else {
                res = 3;
            }
        }

        return res;

    }
    
    
    public double  determinarCuotaModeradora(){
        double res;
        int rango = calcularRangoSalarial();
        if(rango==1){
            res= 3500;
            
        }else{
            if(rango==2){
                res=14000;
                
            }else{
                res=36800;
            }
        }
        return res;
    }
    
    

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }

    public double getCelular() {
        return celular;
    }

    public void setCelular(int celular) {
        this.celular = celular;
    }

    @Override
    public String toString() {
        return "Cotizante:"+ super.toString();
//                "Cotizante{" + "salario=" + salario + ", celular=" + celular +"\n\n"+super.toString()+'}';
    }

}
