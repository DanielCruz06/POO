/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.io.Serializable;
import java.util.ArrayList;
/**
 *
 * @author jose_
 */
public class Paciente implements Serializable{
    protected String nombre;
    protected int numId;
    protected int numResgistro;
    protected ArrayList<ServicioMedico> losServiciosMedicos;
    

    public Paciente(String nombre, int numId, int numResgistro) {
        this.nombre = nombre;
        this.numId = numId;
        this.numResgistro = numResgistro;
        losServiciosMedicos = new ArrayList();
        
    }
    public void agregarServicioMedico(ServicioMedico nuevoSer){
    
        losServiciosMedicos.add(nuevoSer);
    }
    
    
    public double calcularValorPagar(){
        double res=0.0;
        
        return res;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getNumId() {
        return numId;
    }

    public void setNumId(int numId) {
        this.numId = numId;
    }

    public int getNumResgistro() {
        return numResgistro;
    }

    public void setNumResgistro(int numResgistro) {
        this.numResgistro = numResgistro;
    }

    

    @Override
    public String toString() {
        return "nombre: " + nombre + "\n" + "numero de identificacion: " + numId + "\n" + "numero registro: " + numResgistro 
                + "\n\n" + losServiciosMedicos;
        
//                "Paciente" + "nombre=" + nombre + ", numId=" + numId + ", numResgistro=" + numResgistro +"\n\n" +losServiciosMedicos ;
    }
    
    
    
    
    
    
    
    
    
    
    
    
}
